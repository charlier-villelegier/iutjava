package edu.iut.app;

public interface IApplicationLogListener {
	public void newMessage(String level, String message);
}
